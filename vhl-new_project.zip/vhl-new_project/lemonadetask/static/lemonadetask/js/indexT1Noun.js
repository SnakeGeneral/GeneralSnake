const size = 15
const field = document.querySelector('#field_noun');
const letter_container = document.querySelector('#letters_noun');

let firstLetter = -1;

let elements = [];
let words = [];
let position_ids_noun = [];
let score_words = [];

const letterValues = {
	E: 1, N: 1, S: 1, I: 1, R: 1, T: 1, U: 1, A: 1, D: 1,
	H: 1, G: 1, L: 1, O: 1,
	M: 1, B: 1, W: 1, Z: 1,
	C: 1, F: 1, K: 1, P: 1,
	Ä: 1, J: 1, Ü: 1, V: 1,
	Ö: 1, X: 1,
	Q: 1, Y: 1
}

//from droppable.js
const createLetter = (container, letter, draggable = true) => {
	const letter_el = document.createElement('div');
	letter_el.className = 'letter';
	if (draggable) {
		letter_el.classList.add('draggable');
	} else {
		letter_el.classList.add('fixed');
	}
	letter_el.innerText = letter;
	container.appendChild(letter_el);
	
	const value_el = document.createElement('div');
	value_el.className = 'letter-value';
	value_el.innerText = letterValues[letter.toUpperCase()];
	letter_el.appendChild(value_el);
};

//store position of element in field
const init = async (field_state) => {
	for (let y = 0; y < size; y++) {
		elements.push([]);
		for (let x = 0; x < size; x++) {
			const element = document.createElement('div');
			element.id = 'el-' + x + '-' + y;
			element.className = 'element';
			field.appendChild(element);
			elements[y][x] = element;
			
			if (x === 7 && y === 7) {
				element.classList.add('middle');
			}
			
			if (field_state && field_state[x + y * size] != '_') {
				const letter = field_state[x + y * size];
				//make letters one-box-one-letter
				element.classList.add('draggable-dropzone--occupied');
				createLetter(element, letter, false);
			} else {
				if( x == 7 && y == 7){
					element.classList.add('dropzone');
				}
				else {
					element.classList.add('dropzone--occupied');
				}
			}
		}
	}
	
	for (const letter of provided_letters) {
		createLetter(letter_container, letter);
	}
	
	const droppable = new Droppable.default(document.querySelector('.container'), {
		draggable: '.draggable',
		dropzone: '.dropzone'
	});
	
	droppable.on('drag:stop', () => {
		setTimeout(processFieldNoun, 0);
	});
}

//check with wordlist
const isScrabbleWord = async (word) => {
	try {
		const response = await fetch('/validate?word=' + word)
		return (await response.text() === 'true');
	} catch{
		return false;
	}
}

//check with nounlinst
const isScrabbleNoun = async (word) => {
	try {
		const response = await fetch('/validatenoun?noun=' + word)
		return (await response.text() === 'true');
	} catch{
		return false;
	}
}

//check with verblist
const isScrabbleVerb = async (word) => {
	try {
		const response = await fetch('/validateverb?verb=' + word)
		return (await response.text() === 'true');
	} catch{
		return false;
	}
}

const calculateScore = (letters, words) => {
	let score = 0;
	for (const letter of letters) {
		letter.children[0].classList.add('valid');
		const value = getValue(letter);
		//score += letterValues[value.toUpperCase()];
	}
	//score -= previousScore
	return 0;
};



const validateWord = async (wordObject) => {
	let letters = [];
	for(const l of wordObject){
		letters.push(getValue((l)));
	}
	const word = letters.join('');
	return await isScrabbleWord(word);
}

const validateNoun = async (wordObject) => {
	let letters = [];
	for(const l of wordObject){
		letters.push(getValue((l)));
	}
	const word = letters.join('');
	return await isScrabbleNoun(word);
}

const validateVerb = async (wordObject) => {
	let letters = [];
	for(const l of wordObject){
		letters.push(getValue((l)));
	}
	const word = letters.join('');
	return await isScrabbleVerb(word);
}


const removeInvalidLetters = () => {
	for (const row of elements) {
		for (const element of row) {
			if (element.children.length && !element.children[0].classList.contains('valid')) {
				element.children[0].remove();
				element.classList.add('dropzone');
			}
		}
	}
};

const writeStateNoun = (score, calculated) => {
	//Demo round
	document.querySelector('#score_scrabble_noun').innerText = score;
	document.querySelector('input[name="score_scrabble_noun"]').value = score;
	//Main rounds
	if(document.querySelector('#field_state_noun')){	
		document.querySelector('#field_state_noun').value = elements.map(row => row.map(v => getValue(v) || '_').join('')).join('');
		const uniqueWords = [...new Set(words)];
		document.querySelector('#word_list_noun').value = uniqueWords.map(word => word.map(letter => getValue(letter)).join('')).join(' ');
	}
}

const getValue = (element) => {
	const child = element.children[0];
	if (!child) {
		return null;
	}
	return child.firstChild.textContent;
};

const findWords = async (y, x, direction = 0) => {
	let letters = [];
	let pos_ids = "";
	let n = 0;
	let directionVertical = 0;
	
	if (getValue(elements[y][x]) === null || elements[y][x].searched) {
		return [];
	} else {
		elements[y][x].searched = true;
	}
	
	if (direction === 0 || direction === 1) {
		let horizontalWord = [];
		//find leftmost index with letter
		while ((x - (n + 1)) >= 0 && getValue(elements[y][x - (n + 1)]) !== null) {
			n++;
		}
		let leftStart = x - n;
		n = 0;
		//add letters until end of word
		while ((leftStart + n) < size && getValue(elements[y][leftStart + n]) !== null) {
			horizontalWord.push(elements[y][leftStart + n]);
			n++;
		}
		if (horizontalWord.length >= 2 && horizontalWord.length <= 15 && await validateNoun(horizontalWord)) {
			for(i = 0; i < horizontalWord.length; i++){
				pos_ids = pos_ids + horizontalWord[i].id;
			}
			console.log("pos_id : " + pos_ids);
			if(!position_ids_noun.includes(pos_ids)){
				position_ids_noun.push(pos_ids);
				letters.push(...horizontalWord);
				directionVertical += horizontalWord.length;
				words.push(horizontalWord);
				score_words.push(horizontalWord.length);
			}
		}
	}
	pos_ids = "";
	
	if (direction === 0 || direction === 2) {
		let verticalWord = [];
		n = 0;
		while ((y - (n + 1)) >= 0 && getValue(elements[y - (n + 1)][x]) !== null) {
			n++;
		}
		
		let topStart = y - n ;
		n = 0;
		while ((topStart + n) < size && getValue(elements[topStart + n][x]) !== null) {
			verticalWord.push(elements[topStart + n][x]);
			n++;
		}
		if (verticalWord.length >= 2 && verticalWord.length <= 15 && await validateNoun(verticalWord)) {
			for(i = 0; i < verticalWord.length; i++){
				pos_ids = pos_ids + verticalWord[i].id;
			}
			console.log("pos_id : " + pos_ids);
			if(!position_ids_noun.includes(pos_ids)){
				position_ids_noun.push(pos_ids);
				letters.push(...verticalWord);
				words.push(verticalWord);
				score_words.push(verticalWord.length);
			}
		}
	}
	console.log(position_ids_noun);
	//recursion
	letters = [...new Set(letters)];
	
	let index = 0;
	for (const letter of letters) {
		if (!letter.searched) {
			const idSegments = letter.id.split('-');
			const direction = (index < directionVertical) ? 2 : 1;
			letters.push(...await findWords(idSegments[2], idSegments[1], direction));
		}
		index++;
	}
	
	letters = [...new Set(letters)];
	return letters;
};

const removeFlags = () => {
	for (const row of elements) {
		for (const element of row) {
			if (element.searched) {
				delete element.searched;
			}
			if (element.children.length) {
				element.children[0].classList.remove('valid');
			}
		}
	}
	
	for (const letter of letter_container.children) {
		letter.classList.remove('valid');
		delete letter.searched;
	}
}

const processFieldNoun = async (removeInvalid = false) => {
	setOthersOccupied();
	removeFlags();
	words = [];
	position_ids_noun = [];
	const letters = await findWords(7, 7);
	//console.log(letters);
	let score_of_words = 0;
	score_words.forEach(number => {
		score_of_words += number;
	});
	score_words = [];
	const letter_elem = document.querySelector('#letters_noun').className;
	console.log(letter_elem);
	firstLetter = firstLetter + 1;
	calculateScore(letters);
	const score = score_of_words;
	const wordLengths = words.map(array => array.length);
	const calculated = score;
	if (removeInvalid) {
		removeInvalidLetters();
	}
	writeStateNoun(score, calculated);
}

const setOthersOccupied = () => {
	console.log(document.querySelector("#el-7-7").className);
	console.log(document.querySelector("#el-7-7").classList.contains("draggable-dropzone--occupied"));
	if(document.querySelector("#el-7-7").classList.contains("draggable-dropzone--occupied")){
		for (let y = 0; y < size; y++) {
			for (let x = 0; x < size; x++) {
				id = 'el-' + x + '-' + y;
				const element = document.getElementById(id);
				if( !(x == 7 && y == 7)){
					//console.log(x + "-" + y);
					//console.log(y);
					//console.log(x);
					//console.log(y);
					element.classList.remove("dropzone--occupied");
					element.classList.add("dropzone");
				}
				else{
					//element.classList.remove("draggable-dropzone--occupied");
					//element.classList.add("dropzone--occupied");
					element.firstChild.classList.add("non-draggable");
					element.firstChild.classList.remove("draggable");
				}
			}
		}
	}
	else {
		console.log("mid-not-occupied");
	}
}

let field_state_noun = document.querySelector('#field_state_noun_value') ? document.querySelector('#field_state_noun_value').innerText : '';

if (field_state_noun.length === 225) {
	field_state_noun = field_state_noun.split('')
} else {
	field_state_noun = null;
}


init(field_state_noun);
processFieldNoun(true);