
from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
import random
import statistics
import time
from django.http import HttpResponse
global pages

# store all words in a String without _ .
def lettersFromFieldState(field_state: str):
    return len(field_state.replace('_', ''))

# store all words in a String without _ .
def lettersFromValidWords(word_list: str):
    return len(word_list.replace(' ', ''))


# for communication between user (Scrabble field) and server (word list) Django’s URL dispatcher and views are used --> urls.py
def getWordList():
    with open('lemonadetask/data/wordlist.txt', 'r', encoding="utf-8") as file:
        for line in file:
            wordList.append(line.strip())

wordList = []

def getNounList():
    with open('lemonadetask/data/nounlist.txt', 'r', encoding="utf-8") as file:
        for line in file:
            nounList.append(line.strip())

nounList = []

def getVerblist():
    with open('lemonadetask/data/verblist.txt', 'r', encoding="utf-8") as file:
        for line in file:
            verbList.append(line.strip())

verbList = []

def validate_word(request):
    search = request.GET.get('word', '')
    if not wordList:
        getWordList()
    if 2 <= len(search) <= 15:
        search = search.upper()
        for word in wordList:
            if word == search:
                return HttpResponse('true')
    return HttpResponse('false')

def validate_noun(request):
    search = request.GET.get('noun', '')
    print("Search-noun",search)
    if not nounList:
        getNounList()
    if 2 <= len(search) <= 15:
        search = search.upper()
        for word in nounList:
            if word == search:
                return HttpResponse('true')
    return HttpResponse('false')

def validate_verb(request):
    search = request.GET.get('verb', '')
    print("Search-verb",search)
    if not verbList:
        getVerblist()
    if 2 <= len(search) <= 15:
        search = search.upper()
        print("Search-verb-2",search)
        for word in verbList:
            if word == search:
                print("Search-verb-true",search)
                return HttpResponse('true')
    print("Search-verb-false",search)
    return HttpResponse('false')

class SCDecisionNounT1(Page):
    timer_text = 'Verbleibende Zeit für Nomen: '
    form_model = 'player'
    def get_form_fields(self):
            return ['field_state_noun', 'score_scrabble_noun', 'word_list_noun']
    
    def vars_for_template(self):
        # defines which letters, previous word and score are displayed
        plannedLetters = self.participant.vars['plannedLetters']
        print(plannedLetters)
        verb_score = 0
        phase = 'PHASE 1'
        field_state_noun = self.participant.vars['field_state_noun'] if 'field_state_noun' in self.participant.vars else ''
        field_state_verb = self.participant.vars['field_state_verb'] if 'field_state_verb' in self.participant.vars else ''
        if(field_state_noun != '' or field_state_verb != ''):
            phase = 'PHASE 2'
        for r in self.player.in_previous_rounds():
            if(r.score_scrabble_verb is not None):
                verb_score = r.score_scrabble_verb
        return {
            'current_letters': Constants.letters[plannedLetters:self.participant.vars['numberOfLettersNoun'] + plannedLetters],
            'field_state_noun': '',
            'previous_score_scrabble_noun': 0,
            'score_scrabble_verb' : verb_score,
            'phase' : phase
        }
    
    def before_next_page(self):
        self.participant.vars['field_state_verb'] = self.player.field_state_verb
        self.participant.vars['field_state_noun'] = self.player.field_state_noun

    def is_displayed(self):
        if(self.participant.vars['treatment'] == 't1'):
            return self.round_number == self.participant.vars['task_rounds']['SCDecisionNounT1']
        else:
            return False

    def get_timeout_seconds(self):
        return 3600

page_sequence = [SCDecisionNounT1]