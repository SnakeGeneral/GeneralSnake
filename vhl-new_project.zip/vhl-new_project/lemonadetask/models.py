
from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
import random
import itertools

doc = ''
class Constants(BaseConstants):
    name_in_url = 'lemonadetask'
    players_per_group = None
    #num_rounds = 1
    tasks = ['DecisionProduct','DecisionMarketing']
    num_rounds = 1
    #num_rounds = 20
    WestOptSel = 100
    NorthOptSel = 200
    EastOptSel = 60
    #Bliss points for each location
    WestOpenHours = 8.5
    WestPrice = 7.5
    NorthPrice = 2.5
    NorthOpenHours = 6
    EastPrice = 7.5
    EastOpenHours = 3.8
    #Penalties for each location
    WestPricePenalty = 5
    WestOpenHoursPenalty = 5
    WestMarketingPenalty = 20
    WestMarketingOptimal = 1
    BusinessPricePenalty = 3
    NorthPricePenalty = 6
    NorthOpenHoursPenalty = 6
    NorthMarketingPenalty = 60
    NorthMarketingOptimal = 2
    EastPricePenalty = 0.5
    EastOpenHoursPenalty = 0.5
    EastMarketingPenalty = 0.5
    EastMarketingOptimal = 3
    SugarLow = "Some of your customers told you that the lemonade is not sweet enough."
    SugarHigh = "Some of your customers told you that the lemonade is too sweet."
    LemonLow = "Some of your customers told you that the lemonade is not sour/acidic enough."
    LemonHigh = "Some of your customers told you that the lemonade is too sour/acidic."
    PriceLow = "You have too many customers demanding lemonade. The price may be too low."
    PriceHigh = "You have too few customers demanding lemonade. The price may be too high."
    letters = sorted(['N', 'G', 'A', 'U', 'H', 'I', 'D', 'E', 'R', 'S', 'E', 'F', 'Ü', 'V', 'E', 'X', 'K', 'U', 'T', 'G', 'N',
               'E', 'S', 'N', 'S', 'E', 'J', 'U', 'B', 'L', 'Ä', 'A', 'N', 'S', 'O', 'E', 'N', 'H', 'R', 'I', 'C', 'E',
               'F', 'T', 'E', 'W', 'P', 'U', 'R', 'D', 'N', 'E', 'E', 'D', 'A', 'Q', 'T', 'H', 'U', 'O', 'G', 'R', 'C',
               'I', 'E', 'K', 'I', 'Z', 'R', 'M', 'O', 'N', 'T', 'E', 'M', 'R', 'E', 'N', 'S', 'L', 'U', 'B', 'E', 'T',
               'A', 'Y', 'H', 'I', 'Ö', 'T', 'L', 'E', 'N', 'A', 'S', 'S', 'I', 'M', 'D', 'M'],key=str.lower)

class Subsession(BaseSubsession):
    def creating_session(self):
        if self.round_number == 1:
            for p in self.get_players():
                #p.participant.vars['treatment'] = random.choice(['t1','t2','t3','t4'])
                p.participant.vars['treatment'] = random.choice(['t1'])
                p.participant.vars['lemonade_profit'] = 0
                p.participant.vars['plannedLetters'] = 0
                p.participant.vars['numberOfLettersNoun'] = 100
                p.participant.vars['numberOfLettersVerb'] = 100
                p.participant.vars['availableLetters'] = len(Constants.letters) - p.participant.vars['plannedLetters']
                print(p.participant.vars['treatment'])
                self.session.vars['max_round'] = 1
                d1 = {'SCDecisionNounT1': 1}
                dAll = dict(d1)
                p.participant.vars['task_rounds'] = dAll
                print(dAll)

class Group(BaseGroup):
    pass
class Player(BasePlayer):
    def available_letters(self):
        self.participant.vars['availableLetters'] = len(Constants.letters)
    
    # field state is a hidden input field that stores existing words of previous rounds.
    # empty fields have an "_" so that the position of each letter in the field can be accessed.
    field_state_noun = models.TextField(blank=True)
    field_state_verb = models.TextField(blank=True)

    payoff_scrabble = models.IntegerField(blank=True)

     # score is calculated in index.js
    score_scrabble_noun = models.IntegerField(blank=True)
    previous_score_scrabble_noun = models.IntegerField(blank=True)
    word_list_noun = models.TextField(blank=True)

    score_scrabble_verb = models.IntegerField(blank=True)
    previous_score_scrabble_verb = models.IntegerField(blank=True)
    word_list_verb = models.TextField(blank=True)
    
    numberOfLettersNoun = models.IntegerField(min=10, max=100)
    numberOfLettersVerb = models.IntegerField(min=10, max=100)
    
    back=models.IntegerField()
    treatment = models.StringField(blank=True)
    location = models.IntegerField(
        choices=[
            (1, 'Westen'),
            (2, 'Norden'),
            (3, 'Osten'),
        ],
        verbose_name='Standort:',
        widget=widgets.RadioSelectHorizontal,
        blank=True)

    best_location = models.IntegerField(blank=True)
    
    marketing = models.IntegerField(
        choices=[
            (1, 'Aufsteller'),
            (2, 'Flyer'),
            (3, 'Plakat'),
        ],
        verbose_name='Marketing:',
        widget=widgets.RadioSelectHorizontal,
        blank=True)

    best_marketing = models.IntegerField(blank=True)

    price = models.FloatField(
        #min=c(0.0), max=c(10.0),
        verbose_name='Preis:',
        min=10.00, max=20.00,
        blank=True,
        #currency_range=(c(0), c(10), c(0.1))
        #currency_range(c(0), c(0.10), c(0.02))
        widget=widgets.Slider(attrs={'step':0.1,'min':10,'max':20}),
    )
    best_price = models.FloatField(blank=True)

    opening_hours = models.FloatField(
        #min=c(0.0), max=c(10.0),
        verbose_name='Öffnungszeiten:',
        min=10.00, max=20.00,
        blank=True,
        #currency_range=(c(0), c(10), c(0.1))
        #currency_range(c(0), c(0.10), c(0.02))
        widget=widgets.Slider(attrs={'step':0.1,'min':10,'max':20}),
    )
    
    best_opening_hours = models.FloatField(blank=True)

    color = models.IntegerField(
        choices=[
            (1, 'Grün'),
            (2, 'Gelb'),
            (3, 'Orange'),
        ],
        verbose_name='Limonadenfarbe:',
        blank=True,
        widget=widgets.RadioSelectHorizontal)

    best_color = models.IntegerField(blank=True)

    carbonation = models.FloatField(
        min=10, max=20,
        verbose_name='Kohlensäuregehalt:',
        blank=True,
        widget=widgets.Slider(attrs={'step':0.1,'min':10,'max':20}),
    )

    best_carbonation = models.FloatField(blank=True)

    lemon = models.FloatField(
        min=10, max=20,
        verbose_name='Zitronengehalt:',
        blank=True,
        widget=widgets.Slider(attrs={'step':0.1,'min':10,'max':20}),
    )
    best_lemon = models.FloatField(blank=True)

    bottle_label = models.IntegerField(
        choices=[
            (1, 'Dreieckig'),
            (2, 'Rund'),
            (3, 'Quadratisch'),
        ],
        verbose_name='Flaschenetikett:',
        blank=True,
        widget=widgets.RadioSelectHorizontal)

    best_bottle_label = models.IntegerField(blank=True)

    best_product_profit = models.CurrencyField(blank=True)

    best_marketing_profit = models.CurrencyField(blank=True)

    lemonade_profit = models.CurrencyField(blank=True)
   
    profit = models.CurrencyField(doc="profit of the lemonade stand, in thalers")
    
    phase1_marketing_selections = models.LongStringField(blank=True)

    phase1_product_selections = models.LongStringField(blank=True)


    incorrect_lemonade_quiz_attempts=models.IntegerField(initial=0)

    incorrect_scrabble_quiz_attempts=models.IntegerField(initial=0)

    t1_correct_answers_lemonade_q1 = models.IntegerField(initial=0)

    t2_correct_answers_lemonade_q1 = models.IntegerField(initial=0)

    t3_correct_answers_lemonade_q1 = models.IntegerField(initial=0)

    t4_correct_answers_lemonade_q1 = models.IntegerField(initial=0)

    t1_correct_answers_scrabble_q1 = models.IntegerField(initial=0)
    
    t2_correct_answers_scrabble_q1 = models.IntegerField(initial=0)

    t3_correct_answers_scrabble_q1 = models.IntegerField(initial=0)

    t4_correct_answers_scrabble_q1 = models.IntegerField(initial=0)

    quizlemonadecommon1 = models.StringField(
        choices=[['1', 'Ja, die Profitabilität meiner Marktstrategie hängt von meiner Produktstrategie ab.'], ['2', 'Nein, die Profitabilität meiner Marktstrategie hängt nicht von meiner Produktstrategie ab.']],
        label='''1. Hängt die Profitabilität Ihrer Marktstrategie von Ihrer Produktstrategie ab?''',
        widget=widgets.RadioSelect
    )

    quizlemonadecommon2 = models.StringField(
        choices=[['1', 'Ja, ich darf nicht beliebige viele Kombinationen der Merkmale ausprobieren.'], ['2', 'Nein, innerhalb der gegebenen Arbeitszeit kann ich beliebig viele Kombinationen validieren.']],
        label='''2. Ist die Anzahl an Merkmalskombinationen, die Sie innerhalb der gegebenen Arbeitszeit validieren können, begrenzt?''',
        widget=widgets.RadioSelect
    )

    quiz3lemonadeT1 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Produkt- und Marktstrategie arbeiten.'], ['2', 'Nein, ich kann während einer Phase jeweils nur an der Produkt- oder nur an der Marktstrategie arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Produkt- und Marktstrategie arbeiten?''',
        widget=widgets.RadioSelect
    ) 

    quiz4lemonadeT1 = models.StringField(
        choices=[['1', 'Ja, ich kann an den Merkmalen der ersten Phase auch in der zweiten Phase arbeiten.'], ['2', 'Nein, ich kann in der zweiten Phase nicht auch an den Merkmalen der ersten Phase arbeiten.']],
        label='''4. Können Sie in der zweiten Phase an allen Merkmalen der ersten Phase arbeiten?''',
        widget=widgets.RadioSelect
    ) 

    quiz3lemonadeT2 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Produkt- und Marktstrategie arbeiten, jeweils aber nur drei Minuten.'], ['2', 'Nein, ich kann nicht während beiden Phasen an Produkt- und Marktstrategie arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Produkt- und Marktstrategie arbeiten?''',
        widget=widgets.RadioSelect
    ) 

    quiz3lemonadeT3T4 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Produkt- und Marktstrategie arbeiten und dafür unbegrenzt zwischen beiden hin- und herwechseln.'], ['2', 'Nein, ich kann nicht während beiden Phasen an Produkt- und Marktstrategie arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Produkt- und Marktstrategie arbeiten?''',
        widget=widgets.RadioSelect
    ) 

    quiz4lemonadeT2T3T4 = models.StringField(
        choices=[['1', 'Ja, ich kann an den Merkmalen der ersten Phase auch in der zweiten Phase arbeiten.'], ['2', 'Nein, ich kann in der zweiten Phase an vier der acht Merkmale (Farbe und Zitronengehalt bei Produktstrategie, Standort und Preis bei Marktstrategie) nicht mehr arbeiten.']],
        label='''4. Können Sie in der zweiten Phase an allen Merkmalen der ersten Phase arbeiten?''',
        widget=widgets.RadioSelect
    ) 

    quizlemonadecommon5 = models.StringField(
        choices=[['1', 'Es wird die letzte von mir validierte Merkmalskombination berücksichtigt.'], ['2', 'Es wird die von mir validierte Merkmalskombination mit dem höchsten Profit berücksichtigt.'], ['3', 'Es wird der durchschnittliche Profit aller von mir validierten Merkmalskombinationen berücksichtigt.']],
        label='''5. Welche Merkmalskombination innerhalb Ihrer Produkt- bzw. Marktstrategie wird bei der Berechnung Ihrer Vergütung berücksichtigt?''',
        widget=widgets.RadioSelect
    )
        
    quizlemonadecommon6 = models.StringField(
        choices=[['1', 'Ja, der maximal erreichbare Profit in Produkt- und Marktstrategie ist unterschiedlich.'], ['2', 'Nein, der maximal erreichbare Profit in Produkt- und Marktstrategie ist identisch.']],
        label='''6. Ist der maximal erreichbare Profit in Produkt- und Marktstrategie unterschiedlich?''',
        widget=widgets.RadioSelect
    )
        
    quiz7lemonadeT4 = models.StringField(
        choices=[['1', 'Der Profit wird nach jeder Phase getrennt ausgezahlt.'], ['2', 'Der Profit wird am Ende für beide Phasen zusammen ausgezahlt.']],
        label='''7. Wird Ihnen der Profit nach jeder Phase getrennt oder am Ende für beiden Phasen zusammen ausgezahlt?''',
        widget=widgets.RadioSelect
    )

    quiz7lemonadeT1T2T3 = models.StringField(
        choices=[['1', 'Der Profit wird nach jeder Phase getrennt ausgezahlt.'], ['2', 'Der Profit wird am Ende für beide Phasen zusammen ausgezahlt.']],
        label='''7. Wird Ihnen der Profit nach jeder Phase getrennt oder am Ende für beiden Phasen zusammen ausgezahlt?''',
        widget=widgets.RadioSelect
    )

    quizlemonadecommon8 = models.IntegerField()
    
    quizscrabblecommon1 = models.StringField(
        choices=[['1', 'Ja, auf beiden Spielfeldern kann ich sowohl Nomen, als auch Verben legen.'], ['2', 'Nein, auf einem Spielfeld kann ich entweder nur Nomen oder nur Verben legen.']],
        label='''1. Können Sie auf beiden Spielfeldern sowohl Nomen, als auch Verben legen?''',
        widget=widgets.RadioSelect
    )

    quizscrabblecommon2 = models.StringField(
        choices=[['1', 'Ich muss den ersten Buchstaben auf das blaue Feld in der Mitte des Spielfelds legen.'], ['2', 'Ich kann den ersten Buchstaben auf ein beliebiges Feld des Spielfelds legen.']],
        label='''2. Wo müssen Sie den ersten Buchstaben auf jedem Spielfeld legen?''',
        widget=widgets.RadioSelect
    )

    quiz3scrabbleT1 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Nomen und Verben arbeiten.'], ['2', 'Nein, ich kann während einer Phase jeweils nur an Nomen oder nur an Verben arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Nomen und Verben arbeiten?''',
        widget=widgets.RadioSelect
    )

    quiz3scrabbleT2 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Nomen und Verben arbeiten, jeweils aber nur drei Minuten.'], ['2', 'Nein, ich kann nicht während beiden Phasen an Nomen und Verben arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Nomen und Verben arbeiten?''',
        widget=widgets.RadioSelect
    )

    quiz3scrabbleT3T4 = models.StringField(
        choices=[['1', 'Ja, ich kann während beiden Phasen an Nomen und Verben arbeiten und dafür unbegrenzt zwischen beiden hin- und herwechseln.'], ['2', 'Nein, ich kann nicht während beiden Phasen an Nomen und Verben arbeiten.']],
        label='''3. Können Sie in beiden Phasen an Nomen und Verben arbeiten?''',
        widget=widgets.RadioSelect
    )

    quizscrabblecommon4 = models.StringField(
        choices=[['1', 'Ja, ich darf gelegte Wörter jederzeit ändern.'], ['2', 'Nein, ich darf Wörter nur während der Phase, in der sie gelegt werden, verändern und wieder entfernen, nicht aber Wörter aus der ersten Phase in der zweiten Phase ändern.']],
        label='''4. Können Sie in der zweiten Phase gelegte Wörter aus der ersten Phase ändern?''',
        widget=widgets.RadioSelect
    )

    quizscrabblecommon5 = models.StringField(
        choices=[['1', 'Ja'], ['2', 'Nein']],
        label='''5. Müssen alle Wörter auf dem Spielfeld miteinander verbunden sein?''',
        widget=widgets.RadioSelect
    )

    quizscrabblecommon6 = models.StringField(
        choices=[['1', 'Ja'], ['2', 'Nein']],
        label='''6. Müssen alle horizontal oder vertikal aneinandergrenzenden Buchstaben auf dem Spielfeld ein gültiges Wort ergeben?''',
        widget=widgets.RadioSelect
    )

    quiz7scrabbleT4 = models.StringField(
        choices=[['1', 'Der Punktestand wird nach jeder Phase getrennt ausgezahlt.'], ['2', 'Der Punktestand wird am Ende für beide Phasen zusammen ausgezahlt.']],
        label='''7. Wird Ihnen der Punktestand nach jeder Phase getrennt oder am Ende für beide Phasen zusammen ausgezahlt?''',
        widget=widgets.RadioSelect
    )

    quiz7scrabbleT1T2T3 = models.StringField(
        choices=[['1', 'Der Punktestand wird nach jeder Phase getrennt ausgezahlt.'], ['2', 'Der Punktestand wird am Ende für beide Phasen zusammen ausgezahlt.']],
        label='''7. Wird Ihnen der Punktestand nach jeder Phase getrennt oder am Ende für beide Phasen zusammen ausgezahlt?''',
        widget=widgets.RadioSelect
    )

    quizscrabblecommon8 = models.IntegerField()

    def set_profit_marketing(self):
        if self.location == 1:
            if(self.marketing != Constants.WestMarketingOptimal):
                 MarketingPenalty = 1 * Constants.WestMarketingPenalty
            else:
                MarketingPenalty = 0
            OpeningHoursPenalty = abs(Constants.WestOpenHoursPenalty - self.opening_hours) * Constants.WestOpenHoursPenalty
            PricePenalty = abs(Constants.WestPricePenalty - self.price) * Constants.WestPricePenalty
            TotalPenalty = MarketingPenalty + OpeningHoursPenalty + PricePenalty
            if Constants.WestOptSel - TotalPenalty > 0:
                self.profit = Constants.WestOptSel - TotalPenalty
            else:
                self.profit = 0
        if self.location == 2:
            if(self.marketing != Constants.NorthMarketingOptimal):
                 MarketingPenalty = 1 * Constants.NorthMarketingPenalty
            else:
                MarketingPenalty = 0
            OpeningHoursPenalty = abs(Constants.NorthOpenHoursPenalty - self.opening_hours) * Constants.NorthOpenHoursPenalty
            PricePenalty = abs(Constants.NorthPricePenalty - self.price) * Constants.NorthPricePenalty
            TotalPenalty = MarketingPenalty + OpeningHoursPenalty + PricePenalty
            if Constants.NorthOptSel - TotalPenalty > 0:
                self.profit = Constants.NorthOptSel - TotalPenalty
            else:
                self.profit = 0

        if self.location == 3:
            if(self.marketing != Constants.EastMarketingOptimal):
                 MarketingPenalty = 1 * Constants.EastMarketingPenalty
            else:
                MarketingPenalty = 0
            OpeningHoursPenalty = abs(Constants.EastOpenHoursPenalty - self.opening_hours) * Constants.EastOpenHoursPenalty
            PricePenalty = abs(Constants.EastPricePenalty - self.price) * Constants.EastPricePenalty
            TotalPenalty = MarketingPenalty + OpeningHoursPenalty + PricePenalty
            if Constants.EastOptSel - TotalPenalty > 0:
                self.profit = Constants.EastOptSel - TotalPenalty
            else:
                self.profit = 0
                
    def set_payoff_t1(self):
        for r in self.in_previous_rounds():
            if r.best_product_profit is not None and self.best_marketing_profit is not None:
                print(r.best_product_profit)
                print(self.best_product_profit)
                print(r.best_marketing_profit)
                print(self.best_marketing_profit)
                self.payoff = (min(r.best_product_profit,self.best_marketing_profit) / 100)
                r.payoff = (min(r.best_product_profit,self.best_marketing_profit) / 100)
                r.lemonade_profit = (min(r.best_product_profit,self.best_marketing_profit) / 100)
                self.lemonade_profit = (min(r.best_product_profit,self.best_marketing_profit) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            elif r.best_marketing_profit is not None and self.best_product_profit is not None:
                print(r.best_product_profit)
                print(self.best_product_profit)
                print(r.best_marketing_profit)
                print(self.best_marketing_profit)
                self.payoff = (min(self.best_product_profit,r.best_marketing_profit) / 100)
                r.payoff = (min(self.best_product_profit,r.best_marketing_profit) / 100)
                r.lemonade_profit = (min(self.best_product_profit,r.best_marketing_profit) / 100)
                self.lemonade_profit = (min(self.best_product_profit,r.best_marketing_profit) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            else:
                self.payoff = 0
                self.lemonade_profit = 0

    def set_payoff_t2(self):
        for r in self.in_previous_rounds():
            if r.best_product_profit is not None and self.best_marketing_profit is not None:
                print('1')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                product_profit_val = r.best_product_profit + self.best_product_profit
                print('product-profit-val : ', product_profit_val)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                marketing_profit_val = r.best_marketing_profit + self.best_marketing_profit
                print('marketing-profit-val : ', marketing_profit_val)                
                r.payoff = (min(product_profit_val,marketing_profit_val) / 100)
                self.payoff = (min(marketing_profit_val,product_profit_val) / 100)
                r.lemonade_profit = (min(product_profit_val,marketing_profit_val) / 100)
                self.lemonade_profit = (min(marketing_profit_val,product_profit_val) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            elif r.best_marketing_profit is not None and self.best_product_profit is not None:
                print('2')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                product_profit_val = r.best_product_profit + self.best_product_profit
                print('product-profit-val : ', product_profit_val)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                marketing_profit_val = r.best_marketing_profit + self.best_marketing_profit
                print('marketing-profit-val : ', marketing_profit_val)
                r.payoff = (min(product_profit_val,marketing_profit_val) / 100)
                self.payoff = (min(marketing_profit_val,product_profit_val) / 100)
                r.lemonade_profit = (min(product_profit_val,marketing_profit_val) / 100)
                self.lemonade_profit = (min(marketing_profit_val,product_profit_val) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            else:
                print('3')
                self.payoff = 0
                self.lemonade_profit = 0

    def set_payoff_t3(self):
        for r in self.in_previous_rounds():
            if r.best_product_profit is not None and self.best_marketing_profit is not None:
                print('1')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                product_profit_val = r.best_product_profit + self.best_product_profit
                print('product-profit-val : ', product_profit_val)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                marketing_profit_val = r.best_marketing_profit + self.best_marketing_profit
                print('marketing-profit-val : ', marketing_profit_val)                
                r.payoff = (min(product_profit_val,marketing_profit_val) / 100)
                self.payoff = (min(marketing_profit_val,product_profit_val) / 100)
                r.lemonade_profit = (min(product_profit_val,marketing_profit_val) / 100)
                self.lemonade_profit = (min(marketing_profit_val,product_profit_val) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            elif r.best_marketing_profit is not None and self.best_product_profit is not None:
                print('2')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                product_profit_val = r.best_product_profit + self.best_product_profit
                print('product-profit-val : ', product_profit_val)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                marketing_profit_val = r.best_marketing_profit + self.best_marketing_profit
                print('marketing-profit-val : ', marketing_profit_val)
                r.payoff = (min(product_profit_val,marketing_profit_val) / 100)
                self.payoff = (min(marketing_profit_val,product_profit_val) / 100)
                r.lemonade_profit = (min(product_profit_val,marketing_profit_val) / 100)
                self.lemonade_profit = (min(marketing_profit_val,product_profit_val) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            else:
                print('3')
                self.payoff = 0
                self.lemonade_profit = 0

    def set_payoff_t4(self):
        for r in self.in_previous_rounds():
            if r.best_product_profit is not None and self.best_marketing_profit is not None:
                print('1')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                first_round_min = min(r.best_product_profit,r.best_marketing_profit)
                print('first-round-min : ' , first_round_min)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                second_round_min = min(self.best_marketing_profit,self.best_product_profit)
                print('second-round-min : ' , second_round_min)
                r.payoff = ((first_round_min+second_round_min) / 100)
                self.payoff = ((first_round_min+second_round_min) / 100)
                r.lemonade_profit = ((first_round_min+second_round_min) / 100)
                self.lemonade_profit = ((first_round_min+second_round_min) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            elif r.best_marketing_profit is not None and self.best_product_profit is not None:
                print('2')
                print('round-product-profit : ', r.best_product_profit)
                print('self-product-profit : ', self.best_product_profit)
                print('round-marketing-profit : ' , r.best_marketing_profit)
                first_round_min = min(r.best_product_profit,r.best_marketing_profit)
                print('first-round-min : ' , first_round_min)
                print('self-marketing-profit : ' , self.best_marketing_profit)
                second_round_min = min(self.best_marketing_profit,self.best_product_profit)
                print('second-round-min : ' , second_round_min)
                r.payoff = ((first_round_min+second_round_min) / 100)
                self.payoff = ((first_round_min+second_round_min) / 100)
                r.lemonade_profit = ((first_round_min+second_round_min) / 100)
                self.lemonade_profit = ((first_round_min+second_round_min) / 100)
                self.participant.vars['lemonade_profit'] = self.lemonade_profit
            else:
                print('3')
                self.payoff = 0
                self.lemonade_profit = 0
    
    def set_profits(self):
        for r in self.in_previous_rounds():
            if r.best_product_profit is not None and r.best_marketing_profit is not None:
                self.best_marketing_profit = r.best_marketing_profit
                self.best_product_profit = r.best_product_profit
                self.lemonade_profit = (min(r.best_marketing_profit,r.best_product_profit) / 100)
    
    def set_expphase(self):
        if self.location == 1:
            self.maxexpphase = 0
            self.durexpphase = 0
        else:
            if self.round_number==1:
                self.maxexpphase = 1
                self.durexpphase = 1
            else:
                if self.location == self.in_round(self.round_number -1).location and self.color == self.in_round(
                self.round_number -1).color and (abs(self.carbonation-self.in_round(self.round_number -1).carbonation)<0.25) and \
            (abs(self.lemon-self.in_round(self.round_number -1).lemon)<0.25) and (abs(self.price-self.in_round(
                self.round_number -1).price)<0.25):
                    self.maxexpphase = 0
                    self.durexpphase = 0
                else:
                    self.maxexpphase = (1 + self.in_round(self.round_number -1).maxexpphase)
                    self.durexpphase = 1

    def vars_for_template(self):
        return {
            'period1': self.round_number - 2,
            'period2': self.round_number - 1,
            'period3': self.round_number,
        }