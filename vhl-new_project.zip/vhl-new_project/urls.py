from django.conf.urls import url
from otree.urls import urlpatterns
from lemonadetask.pages import validate_word
from lemonadetask.pages import validate_noun
from lemonadetask.pages import validate_verb

urlpatterns.append(url(r'^validate/$', validate_word))
urlpatterns.append(url(r'^validatenoun/$', validate_noun))
urlpatterns.append(url(r'^validateverb/$', validate_verb))