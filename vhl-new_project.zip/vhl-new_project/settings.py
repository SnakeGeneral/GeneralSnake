from os import environ
SESSION_CONFIG_DEFAULTS = {
    'real_world_currency_per_point': 0.01,
    'participation_fee': 4.00,
    'doc': "",
}

SESSION_CONFIGS = [
    {
        'name' : 'Lemonade_stand',
        'display_name' : "Lemonade Stand",
        'num_demo_participants' : 2,
        #'app_sequence': ['Quiz','lemonadetask','Questionnaire'],
        'app_sequence': ['lemonadetask'],
        #'app_sequence': ['lemonadetask','Questionnaire'],
    }
]
LANGUAGE_CODE = 'de'
REAL_WORLD_CURRENCY_CODE = 'ECU'
USE_POINTS = False
DEMO_PAGE_INTRO_HTML = ''
ROOMS = []

ADMIN_USERNAME = 'admin'
# for security, best to set admin password in an environment variable
ADMIN_PASSWORD = environ.get('OTREE_ADMIN_PASSWORD')

SECRET_KEY = 'blahblah'

# if an app is included in SESSION_CONFIGS, you don't need to list it here
INSTALLED_APPS = ['otree']

ROOT_URLCONF = 'urls'

DECIMAL_SEPARATOR = '.'